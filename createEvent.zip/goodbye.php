<?php include_once('header.php'); ?>
<?php include_once('nav.php'); ?>

	<section class="page" id="goodbye-page">
		
			<div class="container-fluid">
				
				<p id="goodbye">
					You are logged out now! <br>
					We hope that you spent nice time with tellastory!
				</p>

			</div>

	</section>

<?php include_once('footer.php'); ?>