<ul class="nav navbar-nav">
	<li><a href="index.php">Home</a></li>
	<li><a href="postcards.php">Postcards</a></li>
	<li><a href="events.php">Events</a></li> 
	<li><a href="login.php">Log in</a></li>
	<li><a class="box-btn" href="signUp.php">Sign up</a></li> 
</ul>