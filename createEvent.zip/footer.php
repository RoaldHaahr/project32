<?php echo '

		<script src="js/jquery-1.11.3.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
	    <script src="js/picturePreview.js"></script>
	</body>
	</html>';
	
?>