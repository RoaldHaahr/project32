	<ul class="nav navbar-nav">
		<li><a href="index.php">Home</a></li>
		<li><a href="#">Postcards</a></li>
		<li><a href="#">Events</a></li> 
		<li><a href="#">My Diary</a></li>
		<li><a href="logout.php">Log out</a></li>
		<li><a href="#" id="nav-profile-picture"><img src="images/michaelwhite.png"></a></li>
		<li><a class="box-btn" href="#">ADD NEW</a></li> 
	</ul>